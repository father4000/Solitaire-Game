package application;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class displayTest 
{
	public static void main(String[] args) 
	{
		//Create a couple piles.
		PlayingCard[] deck = new PlayingCard[13];
		PlayingCard[][] discard = new PlayingCard[13][1];
		ImageView[] discardPileViewImage = new ImageView[13];
		int[] discardPileCount = {6};
		
		//Creating a display object, suit list, and face list.
		Display display = new Display();
		String[] suit = {"spades", "hearts", "diamonds", "clubs"};
		String[] face = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13"};
		
		//Filling piles with playingCard objects.
		for(int i = 0; i < deck.length; i++)
		{
			deck[i] = new PlayingCard();
			discard[i][0] = new PlayingCard();
		}
		
		//Filling discard pile with 13 cards
		for(int i = 0, j = 12; i < discard.length; i++, j--)
		{
			discard[i][0].setFaceValue(face[j]);
			discard[i][0].setSuitValue(suit[i % 4]);
			discard[i][0].setBeenPlayed(true);
		}
		
		//Filling only 6 cards in foundation pile.
		for(int i = 0; i < 7; i++)
		{
			deck[i].setFaceValue(face[i]);
			deck[i].setSuitValue(suit[i % 4]);
			deck[i].setBeenPlayed(true);
			deck[i].setDeckPlacement(i);
		}
		
		//Testing methods from display.
		System.out.println("Testing cardDisplay. Should show 1_of_spades.png \n");
		display.cardDisplay(deck, 0);
	}//End of main

}//End of program.

