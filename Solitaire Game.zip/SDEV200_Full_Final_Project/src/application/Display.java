package application;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

//SDEV200 Final Project
//By Joshua Smith 
//Date: 5/7/23
//Purpose: Display class is used to return image name of cards.

public class Display 
{
	//Constructor
	Display()
	{
		
	}
	
	//Method for showing drawPileCard.
	public String cardDisplay(PlayingCard[] deck, int currentCardIndex)
	{
		return deck[currentCardIndex].getFaceValue() + "_of_" + deck[currentCardIndex].getSuitValue() + ".png";
	}
	
	//Method for updating discardPile images
	public void discardPiles(PlayingCard[] deck, PlayingCard[][] discardPiles, int pileNumber, int[] discardPileCounts, ImageView[] discardPileViewImage)
	{
		//Creating temp display object for method calls.
		Display card = new Display();
		
		for(int i = 1; i < 14; i++)
		{
			if(i <= discardPileCounts[pileNumber])
			{
				discardPileViewImage[i - 1].setImage(new Image(card.cardDisplay(deck, (discardPiles[pileNumber][i]).getDeckPlacement())));
			}
			else
			{
				discardPileViewImage[i - 1].setImage(new Image("back_of_card_red.png"));
			}
		}
	}

}//End of class.
