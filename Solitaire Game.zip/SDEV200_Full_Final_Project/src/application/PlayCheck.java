package application;

//SDEV200 Final Project
//By Joshua Smith 
//Date: 5/7/23
//Purpose: Playcheck is a interface that contains play legal checks.

public interface PlayCheck 
{
	public boolean foundationPlay(PlayingCard card, PlayingCard pileCard, int pileNumberCountToo);
	
	public boolean discardPlay(PlayingCard card, PlayingCard pileCard, int pileNumberCountToo);
}
