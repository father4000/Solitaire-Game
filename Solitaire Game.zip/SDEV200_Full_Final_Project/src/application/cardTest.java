package application;

public class cardTest 
{

	public static void main(String[] args) 
	{
		//Test constructors.
		PlayingCard card1 = new PlayingCard();
		
		//Testing toString method with current cards.
		System.out.println(card1.toString());
		
		//Testing mutators.
		card1.setFaceValue("8");
		card1.setSuitValue("2");
		
		System.out.println("After mutators " + card1.toString());
		
		//Testing accessors
		System.out.println("Accessor test. \n" + "FaceValue: " + card1.getFaceValue() + "\n" + "SuitValue: " + card1.getSuitValue());

	}//End of main.

}//End of program.
