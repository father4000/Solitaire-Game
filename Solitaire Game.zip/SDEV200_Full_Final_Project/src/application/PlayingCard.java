package application;

//SDEV200 Final Project
//By Joshua Smith 
//Date: 5/7/23
//Purpose: PlayingCard class extends Card and implements PlayCheck.

public class PlayingCard extends Card implements PlayCheck
{
	//Creating data fields.
	private boolean beenPlayed = false, inWastePile = false;
	private int deckPlacement = -1;
	
	//Constructors
	PlayingCard()
	{
		this.beenPlayed = false;
		this.deckPlacement = -1;
	}
	
	PlayingCard(boolean beenPlayed, int deckPlacement)
	{
		this.beenPlayed = beenPlayed;
		this.deckPlacement = deckPlacement;
	}
	
	//Mutators
	public void setDeckPlacement(int deckPlacement)
	{
		this.deckPlacement = deckPlacement;
	}
	
	public void setBeenPlayed(boolean beenPlayed)
	{
		this.beenPlayed = beenPlayed;
	}
	
	public void setInWastePile(boolean inWastePile)
	{
		this.inWastePile = inWastePile;
	}
	
	//Accessors
	public int getDeckPlacement()
	{
		return deckPlacement;
	}
	
	public boolean getBeenPlayed()
	{
		return beenPlayed;
	}
	
	public boolean getInWastePile()
	{
		return inWastePile;
	}
	
	//Methods
	@Override
	public boolean foundationPlay(PlayingCard playCard, PlayingCard pileCard, int pileNumberCountToo)
	{
		//Creating data fields.
		int playCardFaceValue = Integer.parseInt(playCard.getFaceValue());
		int pileCardFaceValue = Integer.parseInt(pileCard.getFaceValue());
		boolean isLegal = true;
		//Checking if pile is empty.
		if(pileNumberCountToo == 0)
		{
			isLegal = true;
			return isLegal;
		}
		
		//Checking is cards are the same suit and counting up.
		if(playCard.getSuitValue().equals(pileCard.getSuitValue()) && playCardFaceValue == pileCardFaceValue + 1)
		{
			isLegal = true;
		}
		else
		{
			isLegal = false;
		}
		return isLegal;
	}
	
	@Override
	public boolean discardPlay(PlayingCard playCard, PlayingCard pileCard, int pileNumberCountToo)
	{
		//Creating data fields.
		boolean isLegal = true;
		int playCardSuitGroup = 0;//Group 1 is black and group 2 is red.
		int pileCardSuitGroup = 0;
		int playCardFaceValue = Integer.parseInt(playCard.getFaceValue());
		int pileCardFaceValue = Integer.parseInt(pileCard.getFaceValue());
		
		if(pileNumberCountToo == 0)
		{
			isLegal = true;
			return isLegal;
		}
		//Getting suit group for play card.
		if(playCard.getSuitValue().equals("clubs") || playCard.getSuitValue().equals("spades"))
		{
			playCardSuitGroup = 1;
		}
		else
		{
			playCardSuitGroup = 2;
		}
		//Getting suit group for pile card.
		if(pileCard.getSuitValue().equals("clubs") || pileCard.getSuitValue().equals("spades"))
		{
			pileCardSuitGroup = 1;
		}
		else
		{
			pileCardSuitGroup = 2;
		}
		
		//Checking if cards are not the same color and counting down.
		if(playCardSuitGroup != pileCardSuitGroup && playCardFaceValue == pileCardFaceValue - 1)
		{
			isLegal = true;
		}
		else
		{
			isLegal = false;
		}
		return isLegal;
	}
}//End of class.
