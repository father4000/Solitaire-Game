package application;

public class playingCardTest 
{
	public static void main(String[] args) 
	{
		//Testing constructors.
		PlayingCard card1 = new PlayingCard();
		PlayingCard card2 = new PlayingCard(true, 1);
		
		//Testing mutators.
		card1.setDeckPlacement(20);
		card1.setBeenPlayed(true);
		card1.setFaceValue("10");
		card1.setSuitValue("clubs");
		
		//Testing toString method.
		System.out.println("Testing the toString method from card on playingCard1. - should show 10 and clubs -  \n" + card1.toString());
		//Shoing card 2.
		System.out.println("Showing card 2 defaults. - should be 1 and true - \n" + card2.getDeckPlacement() + " " + card2.getBeenPlayed());
		
		//Testing accessors.
		System.out.println("The deck placement is -should be 20- " + card1.getDeckPlacement());
		System.out.println("The played status is -should be true- " + card1.getBeenPlayed());
		
		//Creating list for method test.
		PlayingCard[] deck =  new PlayingCard[52];
		PlayingCard[] discard = new PlayingCard[52];
		PlayingCard[] foundation = new PlayingCard[52];
		
		//Filling piles with playingCard objects.
		for(int i = 0; i < deck.length; i++)
		{
			deck[i] = new PlayingCard();
			discard[i] = new PlayingCard();
			foundation[i] = new PlayingCard();
		}
		
		//Putting a card in deck, discard, and foundation with values that should return true.
		deck[2].setFaceValue("2");
		deck[2].setSuitValue("clubs");
		discard[4].setFaceValue("3");
		discard[4].setSuitValue("hearts");
		foundation[6].setFaceValue("1");
		foundation[6].setSuitValue("clubs");
		
		//Creating a playingcard for method calls.
		PlayingCard card = new PlayingCard();
		
		//Testing methods for true.
		System.out.println("The discard pile play - should be true -: " + card.discardPlay( deck[2], discard[4], 1));
		System.out.println("The foundation pile play - should be true -: " + deck[2].foundationPlay(deck[2], foundation[6], 1));
		
		//Changing deck card so methods should return false.
		deck[2].setFaceValue("7");
		
		//Testing methods for false.
		System.out.println("The discard pile play - should be false -: " + card.discardPlay( discard[4], deck[2], 1));
		System.out.println("The foundation pile play - should be false -: " + deck[2].foundationPlay(deck[2], foundation[6], 1));
		
	}	
	
}//End of program.
