package application;

//SDEV200 Final Project
//By Joshua Smith 
//Date: 5/7/23
//Purpose: Card class for base card.

public class Card 
{
	private String faceValue = "0", suitValue = "0";
	
	//Mutators
	public void setFaceValue(String faceValue)
	{
		this.faceValue = faceValue;
	}
	
	public void setSuitValue(String suitValue)
	{
		this.suitValue = suitValue;
	}
	
	//Accessors
	public String getFaceValue()
	{
		return faceValue;
	}
	
	public String getSuitValue()
	{
		return suitValue;
	}
	
	public String toString()
	{
		return "Face value is " + faceValue + " and suit value is " + suitValue + ".";
	}

}//End of class.
