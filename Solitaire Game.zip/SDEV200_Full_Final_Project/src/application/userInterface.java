package application;

//SDEV200 Final Project
//By Joshua Smith 
//Date: 5/7/23
//Purpose: userInterface is the entire GUI along with methods for playing game and calling other classes. Methods are broke down for each button starting a action.

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class userInterface extends Application
{
	//Overriding the start method.
	public void start(Stage primaryStage)
	{
		//Creating some data fields.
		int[] playCardIndex = {0};//Current card being played index from one of the piles.
		int[] drawCount = {-1};//Keeps track of current draw card pile index. -1 is no current card drawn.
		int[] pileNumberFrom = {0};//Keeps track of what pile a card play is from.
		int[] discardPileCounts = {0, 0, 0, 0, 0, 0, 0};//Keeps track of how many cards are in each discard pile.
		int[] foundationPileCounts = {0, 0, 0, 0};//Keeps track of how many card are in each foundation pile.
		int[] foundationWinCount = {0};//Keeps track of how many cards are in the foundation piles.52 = a win.
		PlayingCard[] deck = new PlayingCard[52];//Main deck array.
		PlayingCard[][] discardPiles = new PlayingCard[7][14];//Discard pile array.
		PlayingCard[][] foundationPiles = new PlayingCard[4][14];//Foundation pile array.
		Label mainOutPut = new Label("Hit start game to start a new game.");//Label used for main out put.
		
		//Creating UI.
		GridPane mainGrid = new GridPane();
		Button startNewGame = new Button("Start Game");
		Button endGame = new Button("End Game");
		Button draw = new Button("Draw");
		Button viewDiscardPile1 = new Button("View Discard Pile");
		Button viewDiscardPile2 = new Button("View Discard Pile");
		Button viewDiscardPile3 = new Button("View Discard Pile");
		Button viewDiscardPile4 = new Button("View Discard Pile");
		Button viewDiscardPile5 = new Button("View Discard Pile");
		Button viewDiscardPile6 = new Button("View Discard Pile");
		Button viewDiscardPile7 = new Button("View Discard Pile");
		Rectangle blank1 = new Rectangle(150, 200);
		Rectangle blank2 = new Rectangle(150, 200);
		Rectangle blank3 = new Rectangle(350, 200);
		Image drawPile = new Image("back_of_card_red.png");
		Image foundationPile1 = new Image("back_of_card_red.png");
		Image foundationPile2 = new Image("back_of_card_red.png");
		Image foundationPile3 = new Image("back_of_card_red.png");
		Image foundationPile4 = new Image("back_of_card_red.png");
		Image discardPile1 = new Image("back_of_card_red.png");
		Image discardPile2 = new Image("back_of_card_red.png");
		Image discardPile3 = new Image("back_of_card_red.png");
		Image discardPile4 = new Image("back_of_card_red.png");
		Image discardPile5 = new Image("back_of_card_red.png");
		Image discardPile6 = new Image("back_of_card_red.png");
		Image discardPile7 = new Image("back_of_card_red.png");
		
		//Creating discard pile UI.
		GridPane discardGrid = new GridPane();
		Image discardPileViewImage1 = new Image("back_of_card_red.png");
		Image discardPileViewImage2 = new Image("back_of_card_red.png");
		Image discardPileViewImage3 = new Image("back_of_card_red.png");
		Image discardPileViewImage4 = new Image("back_of_card_red.png");
		Image discardPileViewImage5 = new Image("back_of_card_red.png");
		Image discardPileViewImage6 = new Image("back_of_card_red.png");
		Image discardPileViewImage7 = new Image("back_of_card_red.png");
		Image discardPileViewImage8 = new Image("back_of_card_red.png");
		Image discardPileViewImage9 = new Image("back_of_card_red.png");
		Image discardPileViewImage10 = new Image("back_of_card_red.png");
		Image discardPileViewImage11 = new Image("back_of_card_red.png");
		Image discardPileViewImage12 = new Image("back_of_card_red.png");
		Image discardPileViewImage13 = new Image("back_of_card_red.png");
		
		//Adding nodes and some formating.
		blank1.setFill(Color.GREEN);
		blank2.setFill(Color.GREEN);
		blank3.setFill(Color.GREEN);
		mainGrid.setHgap(5);
		mainGrid.setVgap(5);
		mainGrid.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));//Adds boarder
		mainGrid.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
		discardGrid.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
		discardGrid.setHgap(5);
		discardGrid.setVgap(5);
		mainOutPut.setTextFill(Color.BLACK);
		mainOutPut.setFont(Font.font(STYLESHEET_CASPIAN, FontWeight.BOLD, 20));
		mainGrid.add(mainOutPut, 8, 0);
		mainGrid.add(startNewGame, 0, 3);
		mainGrid.add(endGame, 0, 4);
		mainGrid.add(draw, 0, 2);
		mainGrid.add(blank2, 0, 0);//For sizing button column.
		mainGrid.add(blank3, 8, 1);//Sizing 8th column for text output.
		mainGrid.add(viewDiscardPile1, 1, 3);
		mainGrid.add(viewDiscardPile2, 2, 3);
		mainGrid.add(viewDiscardPile3, 3, 3);
		mainGrid.add(viewDiscardPile4, 4, 3);
		mainGrid.add(viewDiscardPile5, 5, 3);
		mainGrid.add(viewDiscardPile6, 6, 3);
		mainGrid.add(viewDiscardPile7, 7, 3);
		
		//Adding image nodes
		ImageView drawPileImage = new ImageView(drawPile);
		ImageView[] foundationPilesImages = new ImageView[4];
		ImageView[] discardPilesImages = new ImageView[7];
		ImageView[] discardPileViewImage = new ImageView[13];
		
		foundationPilesImages[0] = new ImageView(foundationPile1);
		foundationPilesImages[1] = new ImageView(foundationPile2);
		foundationPilesImages[2] = new ImageView(foundationPile3);
		foundationPilesImages[3] = new ImageView(foundationPile4);
		discardPilesImages[0] = new ImageView(discardPile1);
		discardPilesImages[1] = new ImageView(discardPile2);
		discardPilesImages[2] = new ImageView(discardPile3);
		discardPilesImages[3] = new ImageView(discardPile4);
		discardPilesImages[4] = new ImageView(discardPile5);
		discardPilesImages[5] = new ImageView(discardPile6);
		discardPilesImages[6] = new ImageView(discardPile7);
		discardPileViewImage[0] = new ImageView(discardPileViewImage1);
		discardPileViewImage[1] = new ImageView(discardPileViewImage2);
		discardPileViewImage[2] = new ImageView(discardPileViewImage3);
		discardPileViewImage[3] = new ImageView(discardPileViewImage4);
		discardPileViewImage[4] = new ImageView(discardPileViewImage5);
		discardPileViewImage[5] = new ImageView(discardPileViewImage6);
		discardPileViewImage[6] = new ImageView(discardPileViewImage7);
		discardPileViewImage[7] = new ImageView(discardPileViewImage8);
		discardPileViewImage[8] = new ImageView(discardPileViewImage9);
		discardPileViewImage[9] = new ImageView(discardPileViewImage10);
		discardPileViewImage[10] = new ImageView(discardPileViewImage11);
		discardPileViewImage[11] = new ImageView(discardPileViewImage12);
		discardPileViewImage[12] = new ImageView(discardPileViewImage13);
		
		//Some more formatting.
		drawPileImage.setFitHeight(200);
		drawPileImage.setFitWidth(150);
		mainGrid.add(drawPileImage, 2, 1);
		mainGrid.add(blank1, 3, 1);//Adding a blank space between draw and foundation piles.
		foundationPilesImages[0].setFitHeight(200);
		foundationPilesImages[0].setFitWidth(150);
		mainGrid.add(foundationPilesImages[0], 4, 1);
		foundationPilesImages[1].setFitHeight(200);
		foundationPilesImages[1].setFitWidth(150);
		mainGrid.add(foundationPilesImages[1], 5, 1);
		foundationPilesImages[2].setFitHeight(200);
		foundationPilesImages[2].setFitWidth(150);
		mainGrid.add(foundationPilesImages[2], 6, 1);
		foundationPilesImages[3].setFitHeight(200);
		foundationPilesImages[3].setFitWidth(150);
		mainGrid.add(foundationPilesImages[3], 7, 1);
		discardPilesImages[0].setFitHeight(200);
		discardPilesImages[0].setFitWidth(150);
		mainGrid.add(discardPilesImages[0], 1, 2);
		discardPilesImages[1].setFitHeight(200);
		discardPilesImages[1].setFitWidth(150);
		mainGrid.add(discardPilesImages[1], 2, 2);
		discardPilesImages[2].setFitHeight(200);
		discardPilesImages[2].setFitWidth(150);
		mainGrid.add(discardPilesImages[2], 3, 2);
		discardPilesImages[3].setFitHeight(200);
		discardPilesImages[3].setFitWidth(150);
		mainGrid.add(discardPilesImages[3], 4, 2);
		discardPilesImages[4].setFitHeight(200);
		discardPilesImages[4].setFitWidth(150);
		mainGrid.add(discardPilesImages[4], 5, 2);
		discardPilesImages[5].setFitHeight(200);
		discardPilesImages[5].setFitWidth(150);
		mainGrid.add(discardPilesImages[5], 6, 2);
		discardPilesImages[6].setFitHeight(200);
		discardPilesImages[6].setFitWidth(150);
		mainGrid.add(discardPilesImages[6], 7, 2);
		discardPileViewImage[0].setFitHeight(200);
		discardPileViewImage[0].setFitWidth(150);
		discardGrid.add(discardPileViewImage[0], 0, 0);
		discardPileViewImage[1].setFitHeight(200);
		discardPileViewImage[1].setFitWidth(150);
		discardGrid.add(discardPileViewImage[1], 1, 0);
		discardPileViewImage[2].setFitHeight(200);
		discardPileViewImage[2].setFitWidth(150);
		discardGrid.add(discardPileViewImage[2], 2, 0);
		discardPileViewImage[3].setFitHeight(200);
		discardPileViewImage[3].setFitWidth(150);
		discardGrid.add(discardPileViewImage[3], 3, 0);
		discardPileViewImage[4].setFitHeight(200);
		discardPileViewImage[4].setFitWidth(150);
		discardGrid.add(discardPileViewImage[4], 4, 0);
		discardPileViewImage[5].setFitHeight(200);
		discardPileViewImage[5].setFitWidth(150);
		discardGrid.add(discardPileViewImage[5], 5, 0);
		discardPileViewImage[6].setFitHeight(200);
		discardPileViewImage[6].setFitWidth(150);
		discardGrid.add(discardPileViewImage[6], 6, 0);
		discardPileViewImage[7].setFitHeight(200);
		discardPileViewImage[7].setFitWidth(150);
		discardGrid.add(discardPileViewImage[7], 7, 0);
		discardPileViewImage[8].setFitHeight(200);
		discardPileViewImage[8].setFitWidth(150);
		discardGrid.add(discardPileViewImage[8], 8, 0);
		discardPileViewImage[9].setFitHeight(200);
		discardPileViewImage[9].setFitWidth(150);
		discardGrid.add(discardPileViewImage[9], 9, 0);
		discardPileViewImage[10].setFitHeight(200);
		discardPileViewImage[10].setFitWidth(150);
		discardGrid.add(discardPileViewImage[10], 10, 0);
		discardPileViewImage[11].setFitHeight(200);
		discardPileViewImage[11].setFitWidth(150);
		discardGrid.add(discardPileViewImage[11], 11, 0);
		discardPileViewImage[12].setFitHeight(200);
		discardPileViewImage[12].setFitWidth(150);
		discardGrid.add(discardPileViewImage[12], 12, 0);
		
		//Aligning fields in UI.
		mainGrid.setAlignment(Pos.CENTER);
		discardGrid.setAlignment(Pos.CENTER);
		mainGrid.setHalignment(startNewGame, HPos.CENTER);
		mainGrid.setHalignment(endGame, HPos.CENTER);
		mainGrid.setHalignment(draw, HPos.CENTER);
		mainOutPut.setAlignment(Pos.CENTER_LEFT);
		mainGrid.setHalignment(viewDiscardPile1, HPos.CENTER);
		mainGrid.setHalignment(viewDiscardPile2, HPos.CENTER);
		mainGrid.setHalignment(viewDiscardPile3, HPos.CENTER);
		mainGrid.setHalignment(viewDiscardPile4, HPos.CENTER);
		mainGrid.setHalignment(viewDiscardPile5, HPos.CENTER);
		mainGrid.setHalignment(viewDiscardPile6, HPos.CENTER);
		mainGrid.setHalignment(viewDiscardPile7, HPos.CENTER);
		draw.setVisible(false);
		
		//Adding event handlers to images.
		drawPileImage.addEventHandler(MouseEvent.MOUSE_PRESSED, event -> 
		{
			cardSelectedDraw(drawCount, playCardIndex);
			pileNumberFrom[0] = -1;
			event.consume();
		});
		
		discardPilesImages[0].addEventHandler(MouseEvent.MOUSE_CLICKED, event -> 
		{
			if(pileNumberFrom[0] != -2)
			{
				cardDropDiscard(playCardIndex, discardPileCounts, deck, discardPiles,pileNumberFrom, 0, discardPilesImages, drawPileImage, draw, mainOutPut);
			}
			else
			{
				pileNumberFrom[0] = 0;
			}
			event.consume();
		});
		
		discardPilesImages[1].addEventHandler(MouseEvent.MOUSE_CLICKED, event -> 
		{
			if(pileNumberFrom[0] != -2)
			{
				cardDropDiscard(playCardIndex, discardPileCounts, deck, discardPiles,pileNumberFrom, 1, discardPilesImages, drawPileImage, draw, mainOutPut);
			}
			else
			{
				pileNumberFrom[0] = 1;
			}
			event.consume();
		});
		
		discardPilesImages[2].addEventHandler(MouseEvent.MOUSE_CLICKED, event -> 
		{
			if(pileNumberFrom[0] != -2)
			{
				cardDropDiscard(playCardIndex, discardPileCounts, deck, discardPiles,pileNumberFrom, 2, discardPilesImages, drawPileImage, draw, mainOutPut);
			}
			else
			{
				pileNumberFrom[0] = 2;
			}
			event.consume();
		});
		
		discardPilesImages[3].addEventHandler(MouseEvent.MOUSE_CLICKED, event -> 
		{
			if(pileNumberFrom[0] != -2)
			{
				cardDropDiscard(playCardIndex, discardPileCounts, deck, discardPiles,pileNumberFrom, 3, discardPilesImages, drawPileImage, draw, mainOutPut);
			}
			else
			{
				pileNumberFrom[0] = 3;
			}
			event.consume();
		});
		
		discardPilesImages[4].addEventHandler(MouseEvent.MOUSE_CLICKED, event -> 
		{
			if(pileNumberFrom[0] != -2)
			{
				cardDropDiscard(playCardIndex, discardPileCounts, deck, discardPiles,pileNumberFrom, 4, discardPilesImages, drawPileImage, draw, mainOutPut);
			}
			else
			{
				pileNumberFrom[0] = 4;
			}
			event.consume();
		});
		
		discardPilesImages[5].addEventHandler(MouseEvent.MOUSE_CLICKED, event -> 
		{
			if(pileNumberFrom[0] != -2)
			{
				cardDropDiscard(playCardIndex,  discardPileCounts, deck, discardPiles,pileNumberFrom, 5, discardPilesImages, drawPileImage, draw, mainOutPut);
			}
			else
			{
				pileNumberFrom[0] = 5;
			}
			event.consume();
		});
		
		discardPilesImages[6].addEventHandler(MouseEvent.MOUSE_CLICKED, event -> 
		{
			if(pileNumberFrom[0] != -2)
			{
				cardDropDiscard(playCardIndex, discardPileCounts, deck, discardPiles,pileNumberFrom, 6, discardPilesImages, drawPileImage, draw, mainOutPut);
			}
			else
			{
				pileNumberFrom[0] = 6;
			}
			event.consume();
		});
		
		foundationPilesImages[0].addEventHandler(MouseEvent.MOUSE_CLICKED, event ->
		{
			cardDropFoundation(playCardIndex, discardPileCounts, foundationWinCount, deck, discardPiles, foundationPiles, foundationPileCounts, pileNumberFrom, 0, foundationPilesImages, drawPileImage, discardPilesImages, draw, mainOutPut);
			event.consume();
		});
		
		foundationPilesImages[1].addEventHandler(MouseEvent.MOUSE_CLICKED, event ->
		{
			cardDropFoundation(playCardIndex, discardPileCounts, foundationWinCount, deck, discardPiles, foundationPiles, foundationPileCounts, pileNumberFrom, 1, foundationPilesImages, drawPileImage, discardPilesImages, draw, mainOutPut);
			event.consume();
		});
		
		foundationPilesImages[2].addEventHandler(MouseEvent.MOUSE_CLICKED, event ->
		{
			cardDropFoundation(playCardIndex, discardPileCounts, foundationWinCount, deck, discardPiles, foundationPiles, foundationPileCounts, pileNumberFrom, 2, foundationPilesImages, drawPileImage, discardPilesImages, draw, mainOutPut);
			event.consume();
		});
		
		foundationPilesImages[3].addEventHandler(MouseEvent.MOUSE_CLICKED, event ->
		{
			cardDropFoundation(playCardIndex, discardPileCounts, foundationWinCount, deck, discardPiles, foundationPiles, foundationPileCounts, pileNumberFrom, 3, foundationPilesImages, drawPileImage, discardPilesImages, draw, mainOutPut);
			event.consume();
		});
		
		//Event handlers.
		startNewGame.setOnAction(e-> 
		{
			startGameReset(playCardIndex, drawCount, pileNumberFrom, discardPileCounts, foundationPileCounts, foundationWinCount, drawPileImage, foundationPilesImages, discardPilesImages);
			startGame(deck, foundationPiles, discardPiles, draw, startNewGame, mainOutPut);
		});
		endGame.setOnAction(e-> endGame(mainOutPut, foundationWinCount, startNewGame));
		draw.setOnAction(e-> draw(drawPileImage, draw, deck, drawCount, mainOutPut));
		
		//Creating a scene and placing the stage.
		Scene scene = new Scene(mainGrid,1600, 800);
		primaryStage.setTitle("Joshua Smith SDEV200 Final Project");
		primaryStage.setScene(scene);
		primaryStage.show();
		
		//Discard stage set up.
		Stage discardStage = new Stage();
		Scene discardScene = new Scene(discardGrid, 2010, 220);
		discardStage.setTitle("Discard Pile");
		discardStage.setScene(discardScene);
		
		//Event handlers for viewing discard piles.
		viewDiscardPile1.setOnAction(e->
		{
			showDiscardPileStack(deck, discardPiles, 0, discardPileCounts, discardPileViewImage);
			discardStage.show();
			discardStage.requestFocus();
		});
		viewDiscardPile2.setOnAction(e->
		{
			showDiscardPileStack(deck, discardPiles, 1, discardPileCounts, discardPileViewImage);
			discardStage.show();
			discardStage.requestFocus();
		});
		viewDiscardPile3.setOnAction(e->
		{
			showDiscardPileStack(deck, discardPiles, 2, discardPileCounts, discardPileViewImage);
			discardStage.show();
			discardStage.requestFocus();
		});
		viewDiscardPile4.setOnAction(e->
		{
			showDiscardPileStack(deck, discardPiles, 3, discardPileCounts, discardPileViewImage);
			discardStage.show();
			discardStage.requestFocus();
		});
		viewDiscardPile5.setOnAction(e->
		{
			showDiscardPileStack(deck, discardPiles, 4, discardPileCounts, discardPileViewImage);
			discardStage.show();
			discardStage.requestFocus();
		});
		viewDiscardPile6.setOnAction(e->
		{
			showDiscardPileStack(deck, discardPiles, 5, discardPileCounts, discardPileViewImage);
			discardStage.show();
			discardStage.requestFocus();
		});
		viewDiscardPile7.setOnAction(e->
		{
			showDiscardPileStack(deck, discardPiles, 6, discardPileCounts, discardPileViewImage);
			discardStage.show();
			discardStage.requestFocus();
		});
	}//End of GUI.
	
	//Method for drawing.
	private void draw(ImageView drawPileImage, Button draw, PlayingCard[] deck, int[] drawCount, Label mainOutPut)
	{
		if(drawCount[0] != deck.length)
		{
			boolean found = false;
			int tempCount = 0;
			//Finding next card from draw pile.
			while(found == false && tempCount < deck.length)
			{
				if(deck[tempCount].getBeenPlayed() == false && deck[tempCount].getInWastePile() == false)
				{
					drawCount[0] = tempCount;
					found = true;
					deck[tempCount].setInWastePile(true);
				}
				else
				{
					tempCount += 1;
				}
			}
			//Making changes or outputting message,
			if(drawCount[0] < deck.length && deck[drawCount[0]].getBeenPlayed() == false)
			{
				Display card = new Display();//Creates new display object.
				drawPileImage.setImage(new Image(card.cardDisplay(deck, drawCount[0])));//Sets draw pile image to index in deck of drawCount.
				mainOutPut.setText(" Click a card and then \n click where you want \n to place it.");//Setting output message.
			}
			//Moving drawCountForward if no more cards are left to play.
			tempCount = drawCount[0];
			for(int i = drawCount[0]; i < deck.length; i++)
			{
				if(deck[i].getBeenPlayed() == true)
				{
					tempCount += 1;
				}
			}
			if(tempCount == deck.length)
			{
				drawCount[0] = tempCount - 1;
				mainOutPut.setText(" No more cards in draw pile. \n Click draw to reset waste pile \n to draw pile.");
			}	
		}
		else
		{
			//Reseting in waste pile to empty.
			for(int i = 0; i < deck.length - 1; i++)
			{
				deck[i].setInWastePile(false);
			}
			mainOutPut.setText(" Starting at top of waste pile.");
			drawCount[0] = -1;//Reseting drawCount
			drawPileImage.setImage(new Image("back_of_card_red.png"));//Sets draw pile to drawCount after increasing. drawCount starts at -1.
		}
		drawCount[0] += 1;//Increasing draw count by 1.
	}
	
	//Method for showing discard pile stack.
	private void showDiscardPileStack(PlayingCard[] deck, PlayingCard[][] discardPiles, int pileNumber, int[] discardPileCounts, ImageView[] discardPileViewImage)
	{
		//Creating a temp display object for method calls.
		Display card = new Display();
		card.discardPiles(deck, discardPiles, pileNumber, discardPileCounts, discardPileViewImage);
	}
	
	//Data field resets for new game method.
	private void startGameReset(int[] playCardIndex, int[] drawCount, int[] pileNumberFrom, int[] discardPileCounts, int[] foundationPileCounts, int [] foundationWinCount, ImageView drawPileImage, ImageView[] foundationPilesImages, ImageView[] discardPilesImages)
	{
		//Reseting all data fields to starting values.
		playCardIndex[0] = 0;//Current card being played index from one of the piles.
		drawCount[0] = 0;//Keeps track of how many cards have been drawn. 0 is one card drawn.
		pileNumberFrom[0] = 0;//Keeps track of what pile a card play is from.
		foundationWinCount[0] = 0;//Keeps track of how many cards are in the foundation piles.52 = a win.
		for(int i = 0; i < discardPileCounts.length; i++)
		{
			discardPileCounts[i] = 0;
		}
		for(int i = 0; i < foundationPileCounts.length; i++)
		{
			foundationPileCounts[i] = 0;
		}
		for(int i = 0; i < foundationPilesImages.length; i++)
		{
			foundationPilesImages[i].setImage(new Image("back_of_card_red.png"));
		}
		for(int i = 0; i < discardPilesImages.length; i++)
		{
			discardPilesImages[i].setImage(new Image("back_of_card_red.png"));
		}
		drawPileImage.setImage(new Image("back_of_card_red.png"));
	}
	
	//Game start method.
	private void startGame(PlayingCard[] deck, PlayingCard[][] foundationPiles, PlayingCard[][] discardPiles,Button draw,Button startNewGame, Label mainOutPut)
	{
		//Changing button visibility.
		mainOutPut.setText("Hit draw to draw a card.");
		draw.setVisible(true);
		startNewGame.setVisible(false);
		
		//Declaring data fields.
		ArrayList<PlayingCard> shuffleList = new ArrayList<>();
		String[] faceValueString = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13"};
		String[] suitValueString = {"clubs", "diamonds", "hearts", "spades"};
		Random random = new Random(System.currentTimeMillis());
		
		//Initializing deck and shuffleList objects.
		for(int i = 0; i < deck.length; i++)
		{
			deck[i] = new PlayingCard();
			//shuffleList.add(new PlayingCard());
		}
		
		//Initializing foundation pile objects.
		for(int i = 0; i < 4; i++)
		{
			for(int j = 0; j < 13; j++)
			{
				foundationPiles[i][j] = new PlayingCard();
			}
		}
		
		//Initializing discard piles.
		for(int i = 0; i < 7; i++)
		{
			for(int j = 0; j < 13; j++)
			{
				discardPiles[i][j] = new PlayingCard();
			}
		}
				
		//Filling main deck and shuffle with cards.
		int temp = 0;
		for(int i = 0; i < 4; i++)
		{
			for(int j = 0; j < 13; j++)
			{
				deck[temp].setFaceValue(faceValueString[j]);//Setting face value in deck
				deck[temp].setSuitValue(suitValueString[i]);//Setting suit value in deck
				deck[temp].setDeckPlacement(temp);//Setting deck placement to index.
				shuffleList.add(temp, deck[temp]);//Setting deck card to shuffleList.
				temp += 1;
			}
		}
		//Shuffling list
		Collections.shuffle(shuffleList, random);
		
		//Setting new cards from shuffleList to deck.
		for(int i = 0; i < deck.length; i++)
		{
			deck[i] = shuffleList.get(i);//Setting deck to shuffle list.
			deck[i].setDeckPlacement(i);//Setting deckPlacement to match index.
		}
		
	}//End of game start method.
	
	//Method for card selected from draw pile.
	private void cardSelectedDraw(int[] drawCount, int[] playCardIndex)
	{
		playCardIndex[0] = drawCount[0] - 1;
	}
	
	//Method for moving card to foundation pile.
	private void cardDropFoundation(int[] playCardIndex, int[] discardPileCounts, int[] foundationWinCount, PlayingCard[] deck, PlayingCard[][] discardPiles, PlayingCard[][] foundationPiles,int[] foundationPileCounts, int[] pileNumberFrom, int pileNumberToo, ImageView[] foundationPilesImages, ImageView drawPileImage, ImageView[] discardPilesImages, Button draw, Label mainOutPut)
	{
		//Creating a temp PlayingCard object for method calls.
		PlayingCard tempCard = new PlayingCard();
		
		if(pileNumberFrom[0] == -1 && foundationWinCount[0] < 52)//If moving card from draw pile.
		{
			//Making changes or outputting error.
			if(foundationPileCounts[pileNumberToo] != 13 && tempCard.foundationPlay(deck[playCardIndex[0]], foundationPiles[pileNumberToo][foundationPileCounts[pileNumberToo]], foundationPileCounts[pileNumberToo]))
			{
				//Setting data changes.
				Display card = new Display();//Creates new display object.
				foundationPileCounts[pileNumberToo] += 1;//Increasing foundation pile count by 1.
				foundationPiles[pileNumberToo][foundationPileCounts[pileNumberToo]] = deck[playCardIndex[0]];//Copying playCard to foundation pile.
				foundationWinCount[0] += 1;//Increasing the win count.
				deck[playCardIndex[0]].setBeenPlayed(true);//Marking card as played from draw pile.
				//Setting UI changes.
				foundationPilesImages[pileNumberToo].setImage(new Image(card.cardDisplay(deck, playCardIndex[0])));//Setting to card image.
				draw.setVisible(true);//Making draw button visible.
				drawPileImage.setImage(new Image("back_of_card_red.png"));//Reseting draw pile image.
			}
			else
			{
				mainOutPut.setText(" That is not a valid play. \n Card must be of the same suit \n and count up to King.");
			}
		}
		else if(pileNumberFrom[0] != -2 && foundationWinCount[0] < 52)//If moving card from a discard pile.
		{
			//Outputting changes or errors.
			if(tempCard.foundationPlay(discardPiles[pileNumberFrom[0]][discardPileCounts[pileNumberFrom[0]]], foundationPiles[pileNumberToo][foundationPileCounts[pileNumberToo]], foundationPileCounts[pileNumberToo]) == true && foundationPileCounts[pileNumberToo] < 13)
			{
				//Changing data.
				Display card = new Display();//Creating display object.
				foundationPileCounts[pileNumberToo] += 1;//Increasing foundationTo pile count by 1.
				foundationPiles[pileNumberToo][foundationPileCounts[pileNumberToo]] = discardPiles[pileNumberFrom[0]][discardPileCounts[pileNumberFrom[0]]];//Adding top card from pileFrom to pileTo.
				discardPileCounts[pileNumberFrom[0]] -= 1;//Lowering discardFrom pile count.
				//Changing UI.
				foundationPilesImages[pileNumberToo].setImage(new Image(card.cardDisplay(deck, foundationPiles[pileNumberToo][foundationPileCounts[pileNumberToo]].getDeckPlacement())));//Changes image of pile too.
				if(discardPileCounts[pileNumberFrom[0]] == 0)//Sets pile from to lower card or back if empty.
				{
					discardPilesImages[pileNumberFrom[0]].setImage(new Image("back_of_card_red.png"));
				}
				else
				{
					discardPilesImages[pileNumberFrom[0]].setImage(new Image(card.cardDisplay(deck, discardPiles[pileNumberFrom[0]][discardPileCounts[pileNumberFrom[0]]].getDeckPlacement())));
				}
				foundationWinCount[0] += 1;
			}
			else
			{
				mainOutPut.setText(" That is not a valid play. \n Card must be of the same suit \n and count up to King.");
			}
			
		}
		else//If no card is selected.
		{
			mainOutPut.setText(" Please select a card \n to play first.");
		}
		
		if(foundationWinCount[0] == 52)
		{
			draw.setVisible(false);
			mainOutPut.setText(" Congratulations you have won \n !!!!!!!!!!!!!!!!!!!!!!!!!!! \n Your scored a perfect 52!! \n Please hit end game and then \n start game to start a new game. ");
		}
		pileNumberFrom[0] = -2;//Reseting pile number to no selection.
	}
	
	//Method for moving card to discard pile.
	private void cardDropDiscard(int[] playCardIndex,int[] discardPileCounts, PlayingCard[] deck, PlayingCard[][] discardPiles, int[] pileNumberFrom, int pileNumberToo, ImageView[] discardPilesImages, ImageView drawPileImage, Button draw, Label mainOutPut)
	{
		//Creating a temp PlayingCard object for method calls.
		PlayingCard tempCard = new PlayingCard();
		
		if(pileNumberFrom[0] == -1)//If moving card from draw pile.
		{
			//Making changes or outputting error.
			if(tempCard.discardPlay(deck[playCardIndex[0]], discardPiles[pileNumberToo][discardPileCounts[pileNumberToo]], discardPileCounts[pileNumberToo]) && discardPileCounts[pileNumberToo] != 13)
			{
				//Setting data changes.
				Display card = new Display();//Creates new display object.
				discardPileCounts[pileNumberToo] += 1;//Increasing discard pile card count by 1.
				discardPiles[pileNumberToo][discardPileCounts[pileNumberToo]] = deck[playCardIndex[0]];//Copying playCard to discardPile.
				deck[playCardIndex[0]].setBeenPlayed(true);//Marking card as played from draw pile.
				//Setting UI changes.
				discardPilesImages[pileNumberToo].setImage(new Image(card.cardDisplay(deck, playCardIndex[0])));//Setting top card image.
				draw.setVisible(true);//Making draw button visible.
				drawPileImage.setImage(new Image("back_of_card_red.png"));//Reseting draw pile image.
			}
			else//If no card is selected.
			{
				mainOutPut.setText(" That is not a valid play. \n Card must alternate color \n and count down.");
			}
		}
		else if(pileNumberFrom[0] != -2)//If moving card from a discard pile.
		{
			//Outputting changes or errors.
			if(tempCard.discardPlay(discardPiles[pileNumberFrom[0]][discardPileCounts[pileNumberFrom[0]]], discardPiles[pileNumberToo][discardPileCounts[pileNumberToo]], discardPileCounts[pileNumberToo]) == true && discardPileCounts[pileNumberToo] < 13 && discardPileCounts[pileNumberFrom[0]] != 0)
			{
				//Changing data.
				Display card = new Display();//Creating display object.
				discardPileCounts[pileNumberToo] += 1;//Increasing discardToo pile count.
				discardPiles[pileNumberToo][discardPileCounts[pileNumberToo]] = discardPiles[pileNumberFrom[0]][discardPileCounts[pileNumberFrom[0]]];//Adding top card from pileFrom to pileTo.
				discardPileCounts[pileNumberFrom[0]] -= 1;//Lowering discardFrom pile count.
				//Changing UI.
				discardPilesImages[pileNumberToo].setImage(new Image(card.cardDisplay(deck, discardPiles[pileNumberToo][discardPileCounts[pileNumberToo]].getDeckPlacement())));//Change image of pile too.
				if(discardPileCounts[pileNumberFrom[0]] == 0)//Sets pile from to lower card or back if empty.
				{
					discardPilesImages[pileNumberFrom[0]].setImage(new Image("back_of_card_red.png"));
				}
				else
				{
					discardPilesImages[pileNumberFrom[0]].setImage(new Image(card.cardDisplay(deck, discardPiles[pileNumberFrom[0]][discardPileCounts[pileNumberFrom[0]]].getDeckPlacement())));
				}
			}
			else
			{
				mainOutPut.setText(" That is not a valid play. \n Card must alternate color \n and count down.");
			}
		}
		else//If no card is selected.
		{
			mainOutPut.setText(" Please select a card \n to play first.");
		}
		pileNumberFrom[0] = -2;//Reseting pile number to no selection.
	}
	
	//Method for ending early.
	private void endGame(Label mainOutPut, int[] foundationWinCount, Button startNewGame)
	{	
		mainOutPut.setText(" Thanks for playing! \n Your score was " + foundationWinCount[0] + ".");
		startNewGame.setVisible(true);
	}
		
	//Needed for JavaFX
	public static void main(String[] args) 
	{
		Application.launch(args);
	}

}//End of program.